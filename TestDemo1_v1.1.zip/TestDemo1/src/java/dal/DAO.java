/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import com.mysql.cj.protocol.Resultset;
import model.Student;
import java.sql.Connection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import model.Admin;
import model.Classes;
import model.Lecture;
import model.Parent;

/**
 *
 * @author admin
 */
public class DAO extends DBContext {

    private Connection conn;
    private String status = "Ok";
    private List<Student> std;
    private List<Parent> pa;
    private List<Lecture> le;

    public DAO() {
        try {
            conn = new DBContext().getConnection();
        } catch (Exception e) {
            status = "Error at connection" + e.getMessage();
        }
    }

    public List<Student> loadAllStudent() {
        std = new Vector<Student>();
        String sql = "SELECT * FROM [dbo].[Student]";
        try {
            PreparedStatement pre = conn.prepareStatement(sql);
            ResultSet rs = pre.executeQuery();
            while (rs.next()) {
                String id = rs.getString(1);
                String name = rs.getString(2);
                Date dob = rs.getDate(3);
                String email = rs.getString(4);
                String imgUrl = rs.getString(5);
                String username = rs.getString(6);
                std.add(new Student(id, name, dob, email, imgUrl, username));
            }
        } catch (Exception e) {
            status = "Error! Can not connect" + e.getMessage();
        }
        return std;
    }

    public void addStudent(String id, String name, String dob, String email, String imgUrl, String username) {
        String sql = "INSERT INTO Student (id, name, dob, email, imgUrl, username) VALUES (?, ?, ?, ?, ?, ?)";
        try {
            PreparedStatement pre = conn.prepareStatement(sql);
            pre.setString(1, id);
            pre.setString(2, name);
            pre.setString(3, dob);
            pre.setString(4, email);
            pre.setString(5, imgUrl);
            pre.setString(6, username);
            pre.executeUpdate();
        } catch (SQLException e) {
            status = "Error! Can not connect: " + e.getMessage();
        }
    }

    public void deleteStudent(String id) {
        String sql = "DELETE FROM [dbo].[Student]\n"
                + "      WHERE id = ?";
        try {
            PreparedStatement pre = conn.prepareStatement(sql);
            pre.setString(1, id);
            pre.executeUpdate();
        } catch (Exception e) {
        }
    }

    public void updateStudent(String id, String name, String dob, String email, String imgUrl, String username) {
        String sql = "UPDATE [dbo].[Student]\n"
                + "   SET [name] = ?\n"
                + "      ,[dob] = ?\n"
                + "      ,[email] = ?\n"
                + "      ,[imgUrl] = ?\n"
                + "      ,[userName] =?\n"
                + " WHERE [id] = ?";
        try {
            PreparedStatement pre = conn.prepareStatement(sql);
            pre.setString(1, name);
            pre.setString(2, dob);
            pre.setString(3, email);
            pre.setString(4, imgUrl);
            pre.setString(5, username);
            pre.setString(6, id);
            pre.executeUpdate();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public List<Student> getStudentById(String id) {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT * FROM Student WHERE id = ?";
        try {
            PreparedStatement pre = conn.prepareStatement(sql);
            pre.setString(1, id);
            ResultSet res = pre.executeQuery();
            while (res.next()) {
                list.add(new Student(res.getString(1),
                        res.getString(2),
                        res.getDate(3),
                        res.getString(4),
                        res.getString(5),
                        res.getString(6)));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Student> searchStudent(String txtStu) {
        List<Student> list = new ArrayList<>();
        String sql = "select * from Student where name like ?";
        try {
            PreparedStatement pre = conn.prepareStatement(sql);
            pre.setString(1, "%" + txtStu + "%");
            ResultSet res = pre.executeQuery();
            while (res.next()) {
                list.add(new Student(res.getString(1),
                        res.getString(2),
                        res.getDate(3),
                        res.getString(4),
                        res.getString(5),
                        res.getString(6)));
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Better to log or handle this exception properly.
        }
        return list;
    }

    public List<Lecture> loadAllLecture() {
        le = new Vector<Lecture>();
        String sql = "SELECT * FROM [dbo].[Lecture]";
        try {
            PreparedStatement pre = conn.prepareStatement(sql);
            ResultSet res = pre.executeQuery();
            while (res.next()) {
                String id_1 = res.getString("id");
                String name_1 = res.getString("name");
                Date dob_1 = res.getDate("dob");
                String email_1 = res.getString("email");
                String username_1 = res.getString("username");
                le.add(new Lecture(id_1, name_1, dob_1, email_1, username_1));
            }
        } catch (Exception e) {

        }
        return le;
    }

    public void addLecture(String id, String name, Date dob, String email, String username) {
        String sql = "INSERT INTO [dbo].[Lecture]\n"
                + "           ([id]\n"
                + "           ,[name]\n"
                + "           ,[dob]\n"
                + "           ,[email]\n"
                + "           ,[userName])\n"
                + "     VALUES (?, ?, ?, ?, ?)";
        try {
            PreparedStatement pre = conn.prepareStatement(sql);
            pre.setString(1, id);
            pre.setString(2, name);
            pre.setDate(3, dob);
            pre.setString(4, email);
            pre.setString(5, username);
            pre.executeUpdate();
        } catch (SQLException e) {
            status = "Error! Can not connect: " + e.getMessage();
        }
    }

    public void deleteLecture(String id) {
        String sql = "delete from Lecture where id=?";
        try {
            PreparedStatement pre = conn.prepareStatement(sql);
            pre.setString(1, id);
            pre.executeUpdate();
        } catch (Exception e) {
        }
    }

    public void updateLecture(String id, String name, Date dob, String email, String username) {
        String sql = "UPDATE [dbo].[Lecture]\n"
                + "   SET [name] = ?\n"
                + "      ,[dob] = ?\n"
                + "      ,[email] = ?\n"
                + "      ,[userName] = ?\n"
                + " WHERE [id] = ?";
        try {
            PreparedStatement pre = conn.prepareStatement(sql);
            pre.setString(1, name);
            pre.setDate(2, dob);
            pre.setString(3, email);
            pre.setString(4, username);
            pre.setString(5, id);
            pre.executeUpdate();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public List<Lecture> searchLecture(String txtLec) {
        List<Lecture> list = new ArrayList<>();
        String sql = "select * from Lecture where id like ?";
        try {
            PreparedStatement pre = conn.prepareStatement(sql);
            pre.setString(1, "%" + txtLec + "%");
            ResultSet res = pre.executeQuery();
            while (res.next()) {
                list.add(new Lecture(res.getString(1),
                        res.getString(2),
                        res.getDate(3),
                        res.getString(4),
                        res.getString(5)));
            }
        } catch (Exception e) {
        }
        return list;
    }
//
//    public Classes getClassById(int id) {
//        String sql = "Select * from swp2.class\n"
//                + "where idClass = ?;";
//        try {
//            PreparedStatement pre = conn.prepareCall(sql);
//            pre.setInt(1, id);
//            ResultSet rs = pre.executeQuery();
//            if (rs.next()) {
//                Classes c = new Classes(rs.getInt(1),
//                        rs.getString(2),
//                        rs.getDate(3),
//                        rs.getDate(4));
//                return c;
//            }
//        } catch (Exception e) {
//            System.out.println(e);
//        }
//        return null;
//    }
//
//    public Student check(String email) {
//        String sql = "SELECT idStudents, Email, PhoneNumber, Address, DOB FROM swp2.student WHERE Email = ?;";
//        try {
//            PreparedStatement st = conn.prepareStatement(sql);
//            st.setString(1, email);
//            ResultSet rs = st.executeQuery();
//            if (rs.next()) {
//                Student s = new Student(
//                        new BigInteger(rs.getString("idStudents")),
//                        rs.getString("Email"),
//                        rs.getInt("PhoneNumber"),
//                        rs.getString("Address"),
//                        rs.getDate("DOB")
//                );
//                return s;
//            }
//        } catch (SQLException e) {
//            System.out.println(e);
//        }
//        return null;
//    }
//
//    public void loadParent() {
//        pa = new Vector<Parent>();
//        String sql = "select * from swp2.parent";
//        try {
//            PreparedStatement ps = conn.prepareCall(sql);
//            ResultSet rs = ps.executeQuery();
//            while (rs.next()) {
//                pa.add(new Parent(new BigInteger(rs.getString(1)),
//                        rs.getString(2),
//                        rs.getString(3),
//                        rs.getString(4),
//                        rs.getString(5),
//                        rs.getString(6),
//                        rs.getString(7),
//                        rs.getString(8)));
//
//            }
//        } catch (Exception e) {
//            System.out.println(e);
//        }
//    }
//
//    public void addParent(Parent parent) {
//        String sql = "INSERT INTO `mydb32`.`parent`\n"
//                + "(`idParent`,\n"
//                + "`Name`,\n"
//                + "`Address`,\n"
//                + "`Email`,\n"
//                + "`Pass`,\n"
//                + "`Username`,\n"
//                + "`Job`,\n"
//                + "`PlaceOfWork`,\n"
//                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
//        try {
//            PreparedStatement pre = conn.prepareStatement(sql);
//            pre.setBigDecimal(1, new BigDecimal(parent.getId()));
//            pre.setString(2, parent.getName());
//            pre.setString(3, parent.getAdd());
//            pre.setString(4, parent.getEmail());
//            pre.setString(5, parent.getPass());
//            pre.setString(6, parent.getUserName());
//            pre.setString(7, parent.getJob());
//            pre.setString(8, parent.getPlaceOfWork());
//            pre.executeUpdate();
//        } catch (Exception e) {
//
//        }
//    }
//
//    public void deleteParent(String pa_id) {
//        String sql = "delete from `mydb32`.`parent` where idParent=?";
//        try {
//            PreparedStatement pre = conn.prepareStatement(sql);
//            pre.setString(1, pa_id);
//            pre.executeUpdate();
//        } catch (Exception e) {
//        }
//    }
//
//    public Parent checkPa(String userName, String pass) {
//        String sql = "select * from swp2.parent where Username = ? "
//                + "and Pass = ?;";
//        try {
//            PreparedStatement ps = conn.prepareCall(sql);
//            ps.setString(1, userName);
//            ps.setString(2, pass);
//            ResultSet rs = ps.executeQuery();
//            if (rs.next()) {
//                Parent pa = new Parent(new BigInteger(rs.getString("idParent")),
//                        rs.getString("Name"),
//                        rs.getString("Address"),
//                        rs.getString("Email"),
//                        rs.getString("Pass"),
//                        rs.getString("Username"),
//                        rs.getString("Job"),
//                        rs.getString("PlaceOfWork"));
//                return pa;
//            }
//        } catch (Exception e) {
//            System.out.println(e);
//        }
//        return null;
//    }
//
//    public Parent checkPaForgotPassword(String userName, String email) {
//        String sql = """
//                     select * from swp2.parent
//                     where Username = ? and Email = ?;""";
//        try {
//            PreparedStatement ps = conn.prepareCall(sql);
//            ps.setString(1, userName);
//            ps.setString(2, email);
//            ResultSet rs = ps.executeQuery();
//            if (rs.next()) {
//                Parent pa = new Parent(new BigInteger(rs.getString("idParent")),
//                        rs.getString("Name"),
//                        rs.getString("Address"),
//                        rs.getString("Email"),
//                        rs.getString("Pass"),
//                        rs.getString("Username"),
//                        rs.getString("Job"),
//                        rs.getString("PlaceOfWork"));
//                return pa;
//            }
//        } catch (Exception e) {
//            System.out.println(e);
//        }
//        return null;
//    }
//
//    public void updateOTPSentStatus(String username, boolean otpSent) {
//        String sql = "UPDATE swp2.parent SET otp_sent = ? WHERE Username = ?";
//
//        try {
//            PreparedStatement ps = conn.prepareCall(sql);
//            ps.setBoolean(1, otpSent);
//            ps.setString(2, username);
//            ps.executeUpdate();
//        } catch (SQLException e) {
//            System.out.println(e);
//        }
//    }
//
//    public void updatePassword(String username, String newPassword, BigInteger idParent) {
//        String sql = "UPDATE swp2.parent SET Pass = ? WHERE idParent = ? and Username = ?;";
//
//        try {
//            PreparedStatement preparedStatement = conn.prepareCall(sql);
//            preparedStatement.setString(1, newPassword);
//            preparedStatement.setBigDecimal(2, new BigDecimal(idParent));
//            preparedStatement.setString(3, username);
//            preparedStatement.executeUpdate();
//
//        } catch (SQLException e) {
//            System.out.println(e);
//        }
//    }
//
//    public BigInteger getIdParentByUsername(String username) {
//        String sql = "SELECT idParent FROM swp2.parent WHERE Username = ?";
//        BigInteger idParent = null;
//
//        try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
//            preparedStatement.setString(1, username);
//            ResultSet resultSet = preparedStatement.executeQuery();
//
//            if (resultSet.next()) {
//                idParent = new BigInteger(resultSet.getString("idParent"));
//            }
//        } catch (SQLException e) {
//            System.out.println(e);
//        }
//
//        return idParent;
//    }
//
//    public void loadLecture() {
//        le = new Vector<Lecture>();
//        String sql = "select * from swp2.lecture;";
//        try {
//            PreparedStatement ps = conn.prepareCall(sql);
//            ResultSet rs = ps.executeQuery();
//            while (rs.next()) {
//                le.add(new Lecture(new BigInteger(rs.getString(1)),
//                        rs.getString(2),
//                        rs.getString(3),
//                        rs.getInt(4),
//                        rs.getString(5),
//                        rs.getDate(6)));
//            }
//
//        } catch (Exception e) {
//            System.out.println(e);
//        }
//    }
//
//    public void addLecture(BigInteger idLectures, String email, String lectureName, int phoneNumber, String address, Date dateOfBirth) {
//        try {
//            String sql = "INSERT INTO swp2.student (idStudents, Email, PhoneNumber, Address, DOB) VALUES (?, ?, ?, ?, ?)";
//            PreparedStatement pre = conn.prepareStatement(sql);
//            pre.setString(1, idLectures.toString());
//            pre.setString(2, email);
//            pre.setInt(3, phoneNumber);
//            pre.setString(4, address);
//            pre.setDate(5, dateOfBirth);
//            pre.executeUpdate();
//        } catch (SQLException e) {
//            status = "Error! Can not connect: " + e.getMessage();
//        }
//    }
//
//    public Lecture getLectureById(BigInteger id) {
//        Lecture lecture = null;
//        try {
//            String sql = "SELECT * FROM swp2.student WHERE idStudents = ?";
//            PreparedStatement pre = conn.prepareStatement(sql);
//            pre.setString(1, id.toString());
//            ResultSet rs = pre.executeQuery();
//            if (rs.next()) {
//                String email = rs.getString("Email");
//                String lectureName = rs.getString("LectureName");
//                int phoneNumber = rs.getInt("PhoneNumber");
//                String address = rs.getString("Address");
//                Date dateOfBirth = rs.getDate("DOB");
//                lecture = new Lecture(id, email, lectureName, phoneNumber, address, dateOfBirth);
//            }
//        } catch (SQLException e) {
//            status = "Error! Can not connect: " + e.getMessage();
//        }
//        return lecture;
//    }
//
//    public Lecture checkLectureEmail(String email) {
//        String sql = "SELECT idLectures, Email, LectureName, PhoneNumber, "
//                + "Address, DOB FROM swp2.lecture WHERE Email = ?;";
//        try {
//            PreparedStatement ps = conn.prepareCall(sql);
//            ps.setString(1, email);
//            ResultSet rs = ps.executeQuery();
//            while (rs.next()) {
//                Lecture le = new Lecture(new BigInteger(rs.getString(1)),
//                        rs.getString(2),
//                        rs.getString(3),
//                        rs.getInt(4),
//                        rs.getString(5),
//                        rs.getDate(6));
//                return le;
//            }
//        } catch (Exception e) {
//        }
//        return null;
//    }
//
//    public Admin checkAdminEmal(String email) {
//        String sql = "select idAdmin, Email from swp2.admin where Email = ?";
//        try {
//            PreparedStatement ps = conn.prepareCall(sql);
//            ps.setString(1, email);
//            ResultSet rs = ps.executeQuery();
//            while (rs.next()) {
//                Admin ad = new Admin(new BigInteger(rs.getString(1)),
//                        rs.getString(2));
//                return ad;
//            }
//        } catch (Exception e) {
//        }
//        return null;
//    }

    public List<Student> getStd() {
        return std;
    }

    public void setStd(List<Student> std) {
        this.std = std;
    }

    public List<Parent> getPa() {
        return pa;
    }

    public void setPa(List<Parent> pa) {
        this.pa = pa;
    }

    public List<Lecture> getLe() {
        return le;
    }

    public void setLe(List<Lecture> le) {
        this.le = le;
    }

    public static void main(String[] args) {
        DAO d = new DAO();
    }
}
//        String studentIdToDelete = "Ha Van Cuong";
//
//        // Xóa sinh viên
//        System.out.println("Xóa sinh viên có id: " + studentIdToDelete);
//        d.deleteStudent(studentIdToDelete);
//
//        // In ra danh sách sinh viên sau khi xóa
//        System.out.println("Danh sách sinh viên sau khi xóa:");
//        List<Student> list = d.loadAllStudent();
//        if (list.isEmpty()) {
//            System.out.println("Danh sách sinh viên trống.");
//        } else {
//            for (Student stu : list) {
//                System.out.println(stu);
//            }
//        }

//        try {
//            String stu_idToDelete = "4"; // Đặt pa_id bạn muốn xóa
//            d.deleteStudent(stu_idToDelete);
//            System.out.println("Parent with ID " + stu_idToDelete + " has been deleted successfully.");
//        } catch (Exception e) {
//            System.out.println("Error connecting to the database: " + e.getMessage());
//
//        }
//    }
//        // Gọi hàm check với một địa chỉ email để kiểm tra
//        String emailToCheck = "ddominh16@gmail.com";
//        Student resultStudent = d.check(emailToCheck);
//
//        // Kiểm tra kết quả và hiển thị thông tin sinh viên nếu tìm thấy
//        if (resultStudent != null) {
//            System.out.println("Student found:");
//            System.out.println(resultStudent);
//        } else {
//            System.out.println("Student not found for email: " + emailToCheck);
//        }
//        d.loadParent();
//        for (Parent pa : d.getPa()) {
//            System.out.println(pa);
//        }
//        String user = "parent_user";
//        String pass = "password";
//        Parent rs = d.checkPa(user, pass);
//        if (rs != null) {
//            System.out.println("ID: " + rs.getId());
//            System.out.println(rs);
//        } else {
//            System.out.println("not found");
//        }
//        String testUsername = "";
//        String testNewPassword = "new_password";
//        BigInteger testIdParent = new BigInteger("12345"); // Thay đổi giá trị theo idParent thực tế
//
//        try {
//            d.updatePassword(testUsername, testNewPassword, testIdParent);
//            System.out.println("Password updated successfully!");
//        } catch (Exception e) {
//            e.printStackTrace();
//            System.out.println("Failed to update password. Error: " + e.getMessage());
//        }

