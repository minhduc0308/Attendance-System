/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.math.BigInteger;
import java.sql.*;

/**
 *
 * @author admin
 */
//parent, training, class
public class Student {

    private String id;
    private String name;
    private Date dob;
    private String email;
    private String imgUrl;
    private String username;

    public Student() {
    }

    public Student(String id, String name, Date dob, String email, String imgUrl, String username) {
        this.id = id;
        this.name = name;
        this.dob = dob;
        this.email = email;
        this.imgUrl = imgUrl;
        this.username = username;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public String toString() {
        return "Student{" + "id=" + id + ", name=" + name + ", dob=" + dob + ", email=" + email + ", imgUrl=" + imgUrl + ", username=" + username + '}';
    }

    

}
