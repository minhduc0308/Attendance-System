///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
// */
//package dal;
//
//import java.math.BigInteger;
//import java.sql.Date;
//import java.util.List;
//import model.Admin;
//import model.Classes;
//import model.Lecture;
//import model.Parent;
//import model.Student;
//import org.junit.After;
//import org.junit.AfterClass;
//import org.junit.Before;
//import org.junit.BeforeClass;
//import org.junit.Test;
//import static org.junit.Assert.*;
//
///**
// *
// * @author ASUS
// */
//public class DAOTest {
//
//    public DAOTest() {
//    }
//
//    @BeforeClass
//    public static void setUpClass() {
//    }
//
//    @AfterClass
//    public static void tearDownClass() {
//    }
//
//    @Before
//    public void setUp() {
//    }
//
//    @After
//    public void tearDown() {
//    }
//
//    /**
//     * Test of loadAllStudent method, of class DAO.
//     */
//    @Test
//    public void testLoadAllStudent() {
//        System.out.println("loadAllStudent");
//        DAO instance = new DAO();
//        instance.loadAllStudent();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of addStudent method, of class DAO.
//     */
//    @Test
//    public void testAddStudent() {
//        System.out.println("addStudent");
//        BigInteger id = null;
//        String email = "";
//        int phoneNumber = 0;
//        String address = "";
//        Date dob = null;
//        DAO instance = new DAO();
//        instance.addStudent(id, email, phoneNumber, address, dob);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of getClassById method, of class DAO.
//     */
//    @Test
//    public void testGetClassById() {
//        System.out.println("getClassById");
//        int id = 1; // Ví dụ: ID của lớp là 1
//        DAO instance = new DAO();
//        Classes result = instance.getClassById(id);
//        assertNotNull(result);
//        assertEquals(id, result.getId());
//    }
//
//    /**
//     * Test of check method, of class DAO.
//     */
//    @Test
//    public void testCheck() {
//        System.out.println("check");
//        String email = "";
//        DAO instance = new DAO();
//        Student expResult = null;
//        Student result = instance.check(email);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of loadParent method, of class DAO.
//     */
//    @Test
//    public void testLoadParent() {
//        System.out.println("loadParent");
//        DAO instance = new DAO();
//        instance.loadParent();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of addParent method, of class DAO.
//     */
//    @Test
//    public void testAddParent() {
//        System.out.println("addParent");
//        Parent parent = null;
//        DAO instance = new DAO();
//        instance.addParent(parent);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of checkPa method, of class DAO.
//     */
//    @Test
//    public void testCheckPa() {
//        System.out.println("checkPa");
//        // Tạo một tài khoản phụ huynh hợp lệ trong cơ sở dữ liệu
//        String userName = "parent_user2"; // Thay thế "parent_username" bằng tên người dùng thực tế trong cơ sở dữ liệu
//        String pass = "password"; // Thay thế "parent_password" bằng mật khẩu thực tế trong cơ sở dữ liệu
//
//        DAO instance = new DAO();
//        // Gọi phương thức để kiểm tra tài khoản phụ huynh dựa trên tên người dùng và mật khẩu
//        Parent result = instance.checkPa(userName, pass);
//
//        // Kiểm tra xem kết quả có khác null không (tức là tài khoản phụ huynh hợp lệ được trả về)
//        assertNotNull(result);
//
//        // Kiểm tra xem tên người dùng của tài khoản trả về có khớp với tên người dùng đã chỉ định không
//        assertEquals(userName, result.getUserName());
//    }
//
//    /**
//     * Test of checkPaForgotPassword method, of class DAO.
//     */
//    @Test
//    public void testCheckPaForgotPassword() {
//        System.out.println("checkPaForgotPassword");
//        String userName = "";
//        String email = "";
//        DAO instance = new DAO();
//        Parent expResult = null;
//        Parent result = instance.checkPaForgotPassword(userName, email);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of updateOTPSentStatus method, of class DAO.
//     */
//    @Test
//    public void testUpdateOTPSentStatus() {
//        System.out.println("updateOTPSentStatus");
//        String username = "";
//        boolean otpSent = false;
//        DAO instance = new DAO();
//        instance.updateOTPSentStatus(username, otpSent);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of updatePassword method, of class DAO.
//     */
//    @Test
//    public void testUpdatePassword() {
//        System.out.println("updatePassword");
//        String username = "";
//        String newPassword = "";
//        BigInteger idParent = null;
//        DAO instance = new DAO();
//        instance.updatePassword(username, newPassword, idParent);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of getIdParentByUsername method, of class DAO.
//     */
//    @Test
//    public void testGetIdParentByUsername() {
//        System.out.println("getIdParentByUsername");
//        String username = "";
//        DAO instance = new DAO();
//        BigInteger expResult = null;
//        BigInteger result = instance.getIdParentByUsername(username);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of loadLecture method, of class DAO.
//     */
//    @Test
//    public void testLoadLecture() {
//        System.out.println("loadLecture");
//        DAO instance = new DAO();
//        instance.loadLecture();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of addLecture method, of class DAO.
//     */
//    @Test
//    public void testAddLecture() {
//        System.out.println("addLecture");
//        BigInteger idLectures = null;
//        String email = "";
//        String lectureName = "";
//        int phoneNumber = 0;
//        String address = "";
//        Date dateOfBirth = null;
//        DAO instance = new DAO();
//        instance.addLecture(idLectures, email, lectureName, phoneNumber, address, dateOfBirth);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of getLectureById method, of class DAO.
//     */
//    @Test
//    public void testGetLectureById() {
//        System.out.println("getLectureById");
//        BigInteger id = null;
//        DAO instance = new DAO();
//        Lecture expResult = null;
//        Lecture result = instance.getLectureById(id);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of checkLectureEmail method, of class DAO.
//     */
//    @Test
//    public void testCheckLectureEmail() {
//        System.out.println("checkLectureEmail");
//        String email = "";
//        DAO instance = new DAO();
//        Lecture expResult = null;
//        Lecture result = instance.checkLectureEmail(email);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of checkAdminEmal method, of class DAO.
//     */
//    @Test
//    public void testCheckAdminEmal() {
//        System.out.println("checkAdminEmal");
//        String email = "";
//        DAO instance = new DAO();
//        Admin expResult = null;
//        Admin result = instance.checkAdminEmal(email);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of getStd method, of class DAO.
//     */
//    @Test
//    public void testGetStd() {
//        System.out.println("getStd");
//        DAO instance = new DAO();
//        List<Student> expResult = null;
//        List<Student> result = instance.getStd();
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of setStd method, of class DAO.
//     */
//    @Test
//    public void testSetStd() {
//        System.out.println("setStd");
//        List<Student> std = null;
//        DAO instance = new DAO();
//        instance.setStd(std);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of getPa method, of class DAO.
//     */
//    @Test
//    public void testGetPa() {
//        System.out.println("getPa");
//        DAO instance = new DAO();
//        List<Parent> expResult = null;
//        List<Parent> result = instance.getPa();
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of setPa method, of class DAO.
//     */
//    @Test
//    public void testSetPa() {
//        System.out.println("setPa");
//        List<Parent> pa = null;
//        DAO instance = new DAO();
//        instance.setPa(pa);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of getLe method, of class DAO.
//     */
//    @Test
//    public void testGetLe() {
//        System.out.println("getLe");
//        DAO instance = new DAO();
//        List<Lecture> expResult = null;
//        List<Lecture> result = instance.getLe();
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of setLe method, of class DAO.
//     */
//    @Test
//    public void testSetLe() {
//        System.out.println("setLe");
//        List<Lecture> le = null;
//        DAO instance = new DAO();
//        instance.setLe(le);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of main method, of class DAO.
//     */
//    @Test
//    public void testMain() {
//        System.out.println("main");
//        String[] args = null;
//        DAO.main(args);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//}
